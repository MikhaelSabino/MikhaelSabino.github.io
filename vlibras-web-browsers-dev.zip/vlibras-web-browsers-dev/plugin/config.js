// exports.DICTIONARY_URL = 'https://dicionario2.vlibras.gov.br/signs?version=2018.3.1';
// exports.REVIEW_URL = 'https://traducao2.vlibras.gov.br/review';
// exports.SIGNS_URL = 'https://dicionario2.vlibras.gov.br/bundles';

exports.DICTIONARY_URL = 'https://dicionario2-dth.vlibras.gov.br/signs?version=2018.3.1';
exports.REVIEW_URL = 'https://traducao2-dth.vlibras.gov.br/dl/review';
exports.SIGNS_URL = 'https://repositorio-dth.vlibras.gov.br/api/signs';
