const Plugin = require('./Plugin.js');

export { Plugin };
