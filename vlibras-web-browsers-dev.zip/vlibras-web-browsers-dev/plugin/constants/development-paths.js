module.exports = {
  ROOT_PATH: '../../widget/app/',
  
  DICTIONARY_URL: 'https://dicionario2-dth.vlibras.gov.br/signs?version=2018.3.1',
  REVIEW_URL: 'https://traducao2-dth.vlibras.gov.br/dl/review',
  SIGNS_URL: 'https://repositorio-dth.vlibras.gov.br/api/signs',
};
