module.exports = {
  ROOT_PATH: 'https://www.vlibras.gov.br/app/',

  DICTIONARY_URL: 'https://dicionario2.vlibras.gov.br/signs?version=2018.3.1',
  REVIEW_URL: 'https://traducao2.vlibras.gov.br/review',
  SIGNS_URL: 'https://dicionario2.vlibras.gov.br/bundles',
  ACCESS_COUNT_URL: 'https://acessos.vlibras.gov.br/plugin',
};
