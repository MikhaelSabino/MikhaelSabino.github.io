const gulp = require('gulp');
const nodemon = require('gulp-nodemon');
const webpack = require('webpack-stream');
const mergeStream = require('merge-stream');
const webpackConfig = require('./webpack.config.js');

const options = {
  dest: {
    widget: 'widget/app',
    chrome: 'webextensions/chrome.extension/app/player',
    firefox: 'webextensions/firefox.extension/app/player',
  },
};

function build(target, {
  player = 'node_modules/vlibras/src/target/**/*',
  script = 'plugin/index.js',
  template = 'plugin/index.html',
} = {}) {
  const destPath = options.dest[target];

  const webpackCfg = target === 'widget' ? webpackConfig.widgetWebpackConfig : webpackConfig.pluginWebpackConfig;

  const pluginOptions = { cwd: 'plugin', base: 'plugin' };
  const targetOptions = { cwd: target, base: target };

  const playerSrc = gulp.src(player).pipe(gulp.dest(`${destPath}/target`));
  const scriptSrc = gulp.src(script).pipe(webpack(webpackCfg)).pipe(gulp.dest(destPath));
  const templateSrc = gulp.src(template).pipe(gulp.dest(destPath));

  const assetsPluginSrc = gulp.src('assets/*', pluginOptions).pipe(gulp.dest(destPath));
  const assetsTargetSrc = gulp.src('assets/*', targetOptions).pipe(gulp.dest(destPath));
  const fontsPluginSrc = gulp.src('assets/fonts/*', pluginOptions).pipe(gulp.dest(destPath));
  const fontsTargetSrc = gulp.src('assets/fonts/*', targetOptions).pipe(gulp.dest(destPath));

  return mergeStream(
    playerSrc,
    scriptSrc,
    templateSrc,
    assetsPluginSrc,
    assetsTargetSrc,
    fontsPluginSrc,
    fontsTargetSrc
  );
}

gulp.task('build:chrome', () => build('chrome'));
gulp.task('build:firefox', () => build('firefox'));

gulp.task('build:webextensions', gulp.series('build:chrome', 'build:firefox'));

gulp.task('build:widget', () => build('widget', {
  script: 'widget/src/index.js',
  template: 'widget/src/index.html',
}));

gulp.task('build', gulp.series('build:webextensions', 'build:widget'));

gulp.task('run:widget', (done) => nodemon({
  script: 'widget/server.js',
  ext: 'html js scss css',
  watch: ['plugin', 'widget/src', 'widget/assets'],
  tasks: ['build:widget'],
  done,
}));
