const Widget = require('./Widget');

export { Widget };
